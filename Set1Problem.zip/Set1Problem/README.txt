1. Method of running the program is as follows:

C:\Users\Srinivas\Desktop\Set1Problem>python famtree.py C:\Users\Srinivas\Desktop\Set1Problem\Input.txt
CHILD_ADDITION_SUCCEEDED
Aria
Jnki Ahit
PERSON_NOT_FOUND
PERSON_NOT_FOUND
CHILD_ADDITION_FAILED
NONE
Satvy Krpi


2. If no input test file is given as argument then following error occurs:
C:\Users\Srinivas\Desktop\Set1Problem>python famtree.py
No test file location given as argument.

3. If wrong input file is given as argument then following error occurs:
C:\Users\Srinivas\Desktop\Set1Problem>python famtree.py inp
[Errno 2] No such file or directory: 'inp'

